// ===== ULV TOAST SYSTEM =====
// Remplace automatiquement tous les alert() par des toasts pro

(function() {
    // 🎨 Créer le conteneur au chargement
    function creerConteneur() {
        if (document.getElementById('toastContainer')) return;
        var container = document.createElement('div');
        container.id = 'toastContainer';
        container.className = 'toast-container';
        document.body.appendChild(container);
    }

    // 🎨 Injecter le CSS
    function injecterCSS() {
        if (document.getElementById('toast-style')) return;
        var style = document.createElement('style');
        style.id = 'toast-style';
        style.textContent = `
            .toast-container {
                position: fixed;
                top: 80px;
                left: 50%;
                transform: translateX(-50%);
                z-index: 99998;
                display: flex;
                flex-direction: column;
                gap: 10px;
                pointer-events: none;
                width: 90%;
                max-width: 400px;
            }
            .toast {
                background: linear-gradient(135deg, #1e3c72, #2a5298);
                border-radius: 15px;
                padding: 14px 18px;
                display: flex;
                align-items: center;
                gap: 12px;
                box-shadow: 0 8px 25px rgba(0,0,0,0.5);
                border: 1px solid rgba(255,255,255,0.15);
                animation: toastIn 0.4s cubic-bezier(0.5,0,0.5,1);
                pointer-events: auto;
                color: white;
                font-family: Arial, sans-serif;
            }
            .toast.success { border-left: 4px solid #00d4ff; }
            .toast.error { border-left: 4px solid #ff3b7f; }
            .toast.info { border-left: 4px solid #ffcc00; }
            .toast.emoji-toast { border-left: 4px solid #ff00e0; }
            .toast-icone {
                font-size: 22px;
                flex-shrink: 0;
            }
            .toast-message {
                flex: 1;
                font-size: 14px;
                font-weight: bold;
                line-height: 1.3;
                word-wrap: break-word;
            }
            .toast.fermeture {
                animation: toastOut 0.3s cubic-bezier(0.5,0,0.5,1) forwards;
            }
            @keyframes toastIn {
                from { opacity: 0; transform: translateY(-20px); }
                to { opacity: 1; transform: translateY(0); }
            }
            @keyframes toastOut {
                from { opacity: 1; transform: translateY(0); }
                to { opacity: 0; transform: translateY(-20px); }
            }
        `;
        document.head.appendChild(style);
    }

    // 🎨 Afficher un toast
    function afficherToast(message, type) {
        type = type || 'success';
        creerConteneur();

        var container = document.getElementById('toastContainer');
        if (!container) return;

        // 🎯 Auto-détection du type selon le message
        if (!type || type === 'auto') {
            var msgLower = String(message).toLowerCase();
            if (msgLower.indexOf('erreur') !== -1 || msgLower.indexOf('❌') !== -1 || msgLower.indexOf('incorrect') !== -1 || msgLower.indexOf('impossible') !== -1) {
                type = 'error';
            } else if (msgLower.indexOf('bienvenue') !== -1 || msgLower.indexOf('succès') !== -1 || msgLower.indexOf('✅') !== -1 || msgLower.indexOf('publié') !== -1 || msgLower.indexOf('abonné') !== -1 || msgLower.indexOf('modifié') !== -1 || msgLower.indexOf('supprimé') !== -1) {
                type = 'success';
            } else if (msgLower.indexOf('déconnecté') !== -1 || msgLower.indexOf('désabonné') !== -1 || msgLower.indexOf('attention') !== -1) {
                type = 'info';
            } else {
                type = 'info';
            }
        }

        var icones = {
            success: '✅',
            error: '❌',
            info: 'ℹ️',
            emoji: '✨'
        };

        // Détecter emoji déjà présent dans le message
        var messageClean = String(message);
        var icone = icones[type] || '✅';
        
        // Si le message commence déjà par un emoji, on l'utilise
        var emojiMatch = messageClean.match(/^([\u{1F300}-\u{1FAFF}\u{2600}-\u{27BF}]+)\s*/u);
        if (emojiMatch) {
            icone = emojiMatch[1];
            messageClean = messageClean.replace(/^[\u{1F300}-\u{1FAFF}\u{2600}-\u{27BF}]+\s*/u, '');
        }

        var toast = document.createElement('div');
        toast.className = 'toast ' + type;
        toast.innerHTML = 
            '<div class="toast-icone">' + icone + '</div>' +
            '<div class="toast-message">' + messageClean + '</div>';

        container.appendChild(toast);

        // Disparaît après 2.5 secondes
        setTimeout(function() {
            toast.classList.add('fermeture');
            setTimeout(function() {
                if (toast.parentNode) toast.parentNode.removeChild(toast);
            }, 300);
        }, 2500);
    }

    // 🔥 MAGIE : on remplace window.alert par notre toast
    window.alertOriginal = window.alert;
    window.alert = function(message) {
        // Si le message est trop long (genre multi-lignes), on garde l'alert normal
        if (String(message).length > 150 || String(message).split('\n').length > 3) {
            window.alertOriginal(message);
            return;
        }
        afficherToast(message, 'auto');
    };

    // Exposer la fonction pour usage manuel
    window.afficherToast = afficherToast;

    // Créer le conteneur dès que possible
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', function() {
            injecterCSS();
            creerConteneur();
        });
    } else {
        injecterCSS();
        creerConteneur();
    }

    console.log('🍞 ULV Toast System chargé');
})();