// ===== ULV SERVICE WORKER =====
// Gère le cache pour que ULV soit rapide et marche hors ligne

const CACHE_NAME = 'ulv-v3';

// Fichiers à cacher dès le départ
const FICHIERS_A_CACHER = [
    'index.html',
    'inscription.html',
    'connexion.html',
    'accueil.html',
    'profil.html',
    'profil-public.html',
    'editer-profil.html',
    'messages.html',
    'marketplace.html',
    'notifications.html',
    'recherche.html',
    'jeux.html',
    'morpion.html',
    'pfc.html',
    'puissance4.html',
    'echecs.html',
    'classement.html',
    'defier.html',
    'parametres.html',
    'supabase-config.js',
    'manifest.json'
];

// 🔥 INSTALLATION : on cache tous les fichiers
self.addEventListener('install', function(event) {
    console.log('🔧 ULV : Installation du Service Worker');
    event.waitUntil(
        caches.open(CACHE_NAME).then(function(cache) {
            console.log('📦 ULV : Mise en cache des fichiers');
            return cache.addAll(FICHIERS_A_CACHER.map(function(url) {
                return new Request(url, { cache: 'reload' });
            })).catch(function(err) {
                console.log('⚠️ Certains fichiers non cachés:', err);
            });
        })
    );
    self.skipWaiting();
});

// 🔥 ACTIVATION : on supprime les anciens caches
self.addEventListener('activate', function(event) {
    console.log('✅ ULV : Service Worker activé');
    event.waitUntil(
        caches.keys().then(function(nomsCache) {
            return Promise.all(
                nomsCache.map(function(nom) {
                    if (nom !== CACHE_NAME) {
                        console.log('🗑️ Suppression ancien cache:', nom);
                        return caches.delete(nom);
                    }
                })
            );
        })
    );
    self.clients.claim();
});

// 🔥 FETCH : interception des requêtes
self.addEventListener('fetch', function(event) {
    const url = event.request.url;

    // Ne pas cacher les requêtes Supabase (API)
    if (url.includes('supabase.co')) {
        // Network-first avec timeout
        event.respondWith(
            fetch(event.request).catch(function() {
                return new Response(JSON.stringify({ error: 'offline' }), {
                    headers: { 'Content-Type': 'application/json' }
                });
            })
        );
        return;
    }

    // Ne pas cacher les autres domaines
    if (!url.startsWith(self.location.origin)) {
        return;
    }

    // Cache-first pour les fichiers statiques
    event.respondWith(
        caches.match(event.request).then(function(response) {
            if (response) {
                // ✅ Trouvé en cache : on retourne
                // En arrière-plan, on met à jour le cache
                fetch(event.request).then(function(nouvelleReponse) {
                    if (nouvelleReponse && nouvelleReponse.status === 200) {
                        caches.open(CACHE_NAME).then(function(cache) {
                            cache.put(event.request, nouvelleReponse);
                        });
                    }
                }).catch(function() {});
                return response;
            }

            // ❌ Pas en cache : on va chercher sur le réseau
            return fetch(event.request).then(function(response) {
                if (!response || response.status !== 200 || response.type !== 'basic') {
                    return response;
                }

                // On met en cache pour la prochaine fois
                const responseClone = response.clone();
                caches.open(CACHE_NAME).then(function(cache) {
                    cache.put(event.request, responseClone);
                });

                return response;
            }).catch(function() {
                // Si pas de réseau et pas en cache → page hors ligne
                return new Response('<html><body style="background:#0f1a2e;color:white;font-family:Arial;text-align:center;padding:50px;"><h1>📶 Hors ligne</h1><p>Vérifie ta connexion internet</p><button onclick="location.reload()" style="margin-top:20px;padding:12px 25px;background:linear-gradient(90deg,#00d4ff,#ff00e0);border:none;border-radius:25px;color:white;font-weight:bold;font-size:15px;">🔄 Réessayer</button></body></html>', {
                    headers: { 'Content-Type': 'text/html' }
                });
            });
        })
    );
});

console.log('🚀 ULV Service Worker chargé');