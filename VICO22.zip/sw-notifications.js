// sw-notifications.js
self.addEventListener('install', function(e) { self.skipWaiting(); });
self.addEventListener('activate', function(e) { e.waitUntil(self.clients.claim()); });

// Recevoir un ordre depuis la page
self.addEventListener('message', function(event) {
    if (event.data && event.data.type === 'AFFICHER_NOTIF') {
        var d = event.data.notif;
        self.registration.showNotification(d.titre || 'ULV', {
            body: d.body || '',
            icon: '/icon-192.png',
            badge: '/icon-192.png',
            tag: d.tag || 'ulv-notif',
            data: { url: d.url || '/' }
        });
    }
});

// Quand on clique sur la notif → ouvrir ULV
self.addEventListener('notificationclick', function(event) {
    event.notification.close();
    var url = (event.notification.data && event.notification.data.url) || '/';
    event.waitUntil(clients.openWindow(url));
});