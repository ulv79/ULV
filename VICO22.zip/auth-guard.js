// ============================================
// 🛡️ AUTH-GUARD ULV
// À inclure dans toutes les pages protégées
// ============================================

(function() {
    // ⚡ Vérification rapide de la session
    (async function() {
        if (typeof supabaseClient === 'undefined') {
            console.error('❌ supabase-config.js non chargé');
            return;
        }

        try {
            // 1️⃣ Vérifier la session Supabase
            var res = await supabaseClient.auth.getSession();

            if (!res.data || !res.data.session) {
                console.log('🔒 Pas de session, redirection vers connexion');
                localStorage.removeItem('ulv_connecte');
                window.location.href = 'connexion.html';
                return;
            }

            // 2️⃣ Session OK → récupérer le user
            var user = res.data.session.user;
            var metadata = user.user_metadata || {};

            var nom = metadata.nom || user.email.split('@')[0];
            var pseudo = metadata.pseudo || '';

            // 3️⃣ Rafraîchir le localStorage (compatibilité avec ton code existant)
            localStorage.setItem('ulv_nom', nom);
            localStorage.setItem('ulv_pseudo', pseudo);
            localStorage.setItem('ulv_email', user.email);
            localStorage.setItem('ulv_auth_id', user.id);
            localStorage.setItem('ulv_connecte', 'oui');

            // 4️⃣ Rafraîchir depuis la table users en arrière-plan
            try {
                var userRes = await supabaseClient.from('users').select('*').eq('auth_id', user.id).limit(1);
                var userData = (userRes.data && userRes.data[0]) || null;

                if (userData) {
                    if (userData.tel) localStorage.setItem('ulv_tel', userData.tel);
                    if (userData.pays) localStorage.setItem('ulv_pays', userData.pays);
                    if (userData.photo_profil) localStorage.setItem('ulv_photo', userData.photo_profil);
                    if (userData.bio) localStorage.setItem('ulv_bio', userData.bio);
                    if (userData.pseudo) localStorage.setItem('ulv_pseudo', userData.pseudo);
                }
            } catch(e) {
                console.warn('⚠️ Erreur refresh user:', e.message);
            }

            console.log('✅ Session valide pour:', nom);

        } catch(e) {
            console.error('❌ Erreur auth-guard:', e);
            localStorage.removeItem('ulv_connecte');
            window.location.href = 'connexion.html';
        }
    })();
})();

// 🚪 Fonction de déconnexion globale
window.deconnecter = async function() {
    if (!confirm('Te déconnecter de ULV ?')) return;
    try {
        await supabaseClient.auth.signOut();
    } catch(e) { console.warn('Erreur signOut:', e); }
    localStorage.clear();
    window.location.href = 'connexion.html';
};