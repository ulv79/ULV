// ===== CONFIGURATION SUPABASE ULV =====
const SUPABASE_URL = 'https://beumtitdnjfxgbtomags.supabase.co';
const SUPABASE_KEY = 'sb_publishable_QD7a6OGpFlQqzc8-Hu9S8A_Q6JuSqst';

const _client = window.supabase.createClient(SUPABASE_URL, SUPABASE_KEY);

// ⏱️ TIMEOUT MAX 10 SECONDES
const TIMEOUT_MS = 10000;

function avecTimeout(promise) {
    return Promise.race([
        promise,
        new Promise(function(_, reject) {
            setTimeout(function() {
                reject(new Error('Timeout Supabase (' + TIMEOUT_MS + 'ms)'));
            }, TIMEOUT_MS);
        })
    ]);
}

// 🔥 WRAPPER intelligent qui garde le chaînage
function wrapQuery(builder) {
    return new Proxy(builder, {
        get: function(target, prop) {
            // Quand on await le builder, on applique le timeout
            if (prop === 'then') {
                return function(onFulfilled, onRejected) {
                    return avecTimeout(target).then(onFulfilled, onRejected);
                };
            }
            // Pour les autres propriétés
            const value = target[prop];
            if (typeof value === 'function') {
                return function() {
                    const result = value.apply(target, arguments);
                    // Si la méthode retourne un builder (chaînable), on le wrap
                    if (result && typeof result.then === 'function') {
                        return wrapQuery(result);
                    }
                    return result;
                };
            }
            return value;
        }
    });
}

// Client Supabase final
const supabaseClient = {
    from: function(table) {
        return wrapQuery(_client.from(table));
    },
    storage: _client.storage,
    auth: _client.auth,
    rpc: _client.rpc.bind(_client)
};

console.log('🚀 Supabase configuré avec timeout ' + TIMEOUT_MS + 'ms');